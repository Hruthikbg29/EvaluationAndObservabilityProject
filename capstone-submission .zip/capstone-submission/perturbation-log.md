### System 1 — validated, routed pipeline

- **Change I made (file + what I changed):**
  Used the provided missing-source perturbation in `tests/test_us01_retry.py`. The recorded extraction response sets the required `endorsements` field to `None`, representing that Schedule A was absent from the source.

- **Command I ran:**
  `.venv/bin/pytest tests/test_us01_retry.py -v`

- **What I predicted:**
  Because a required field is genuinely absent from the source, the system should stop rather than make unnecessary retry API calls, and escalate the case as `RetryFutileEscalation`.

- **What actually happened (paste the key output line):**
  `assert isinstance(result, RetryFutileEscalation)`  
  `assert result.field == "endorsements"`  
  `assert result.detected_pattern == "endorsements_absent"`  
  `assert client.call_count == 1  # no further API call`

- **How this differs from the unperturbed run:**
  The normal routing tests include successful routing cases such as all-clear routing to `auto_approve`, while this missing-source case is escalated as `RetryFutileEscalation` after exactly one API call instead of continuing retries.

### System 2 — resilient mortgage extraction

- **Change I made (file + what I changed):**
  Changed the recorded response fixture `fixtures/recorded_responses/1c76db72dd978c9c.json`, setting `stated_monthly_total` from `10892.17` to `12000.00`.

- **Command I ran:**
  `.venv/bin/mortgage-extract --mode replay fixtures/documents/income_sum_mismatch.txt`

- **What I predicted:**
  The validator should retain the calculated line-item total of `9642.17` but use the perturbed stated total of `12000.00`, producing a larger discrepancy.

- **What actually happened (key output):**
  `"stated_monthly_total": 12000.0`, `"calculated": 9642.17`, `"delta": -2357.83`, and `"consistent": false`.

- **How this differs from the unperturbed run:**
  The baseline reported stated total `10892.17` and delta `-1250.0`. After perturbing the recorded response fixture, the calculated total remained `9642.17`, while the stated total changed to `12000.0` and the delta changed to `-2357.83`. This demonstrates that the mathematical-consistency validator reacts to the perturbed recorded value. This was a replay/fixture perturbation, not a fresh live LLM extraction.

### System 3 — supply-chain risk investigation

- **Change I made (file + what I changed):**
  Used the provided timeout perturbation by enabling `--simulate-timeout` for the logistics source.

- **Command I ran:**
  `.venv/bin/supply-chain-investigate meridian --offline --simulate-timeout`

- **What I predicted:**
  The timed-out logistics source should not be treated as valid evidence. The affected metric should instead be reported as incomplete.

- **What actually happened (paste the key output line):**
  `### late_shipment_count _[missing source: timeout reading logistics]_`
  `- missing source: timeout reading logistics`

- **How this differs from the unperturbed run:**
  In the normal offline investigation, `on_time_delivery_rate` was reported as contested between the supplier audit value of `95.0 percent` and logistics value of `78.0 percent`. With the simulated timeout, `late_shipment_count` became incomplete because the logistics source could not be read. `production_capacity_utilization` remained incomplete because no source reported that metric.
