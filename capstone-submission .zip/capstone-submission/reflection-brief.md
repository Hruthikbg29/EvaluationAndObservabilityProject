**Name:**  
**Date:** 2026-09-23

> Ground every answer in your own run. When a question asks for a number, file name, or line, paste it from your artifacts — a reviewer should be able to find it. Answers that are correct in the abstract but cite nothing do not meet the bar. Keep it short and specific.

---

## 0. Environment

| Field | Value |
|---|---|
| OS & version | Linux 6.6.97+ x86_64 |
| Python version | Python 3.13.0 |
| Date run | 2026-09-23 |
| Ran any system live? (which) | No. System 1 live pipeline was attempted but could not authenticate; offline/fallback evidence was used. |

---

## 1. Validated, routed pipeline

| Evidence | Value |
|---|---|
| Passing test count | 45 passed, 3 skipped |
| Routing output file | Not generated — live Vocareum request returned HTTP 400 because the service budget was exceeded |
| auto_approve / human_review / spot_check counts | Not available from the live routing output |

### 1a. Retry boundary

> The required `endorsements` field was `None`, representing an absent Schedule A. The perturbation test asserted `RetryFutileEscalation`, `result.field == "endorsements"`, `result.detected_pattern == "endorsements_absent"`, and `client.call_count == 1`. The system therefore made exactly 1 API call. Retrying a case where the required source information is genuinely absent would make unnecessary calls without changing the available evidence, so escalation is preferable.

### 1b. Reading the router

> A live `routing_decisions.json` record was not available because the configured Vocareum request reached `https://claude.vocareum.com/v1/messages` but returned HTTP 400 with a service-budget-exceeded error. The offline routing tests in `tests/test_us04_routing.py` verify human-review routing for low confidence, integration failure, and reviewer disagreement, but they do not provide a live routing record that can be quoted here.

### 1c. Where the aggregate lies

> `umbrella exclusions n=2 conf=0.93 acc=0.00 brier=0.865`  
> `OVERALL brier=0.291`
>
> The umbrella/exclusions slice had 0.00 accuracy despite 0.93 confidence. Slicing by `policy_type × field` exposes a poorly performing subgroup that an overall aggregate can hide.

---

## 2. Schema-enforced two-pass extraction

| Evidence | Value |
|---|---|
| Passing test count | 25 passed |
| Document run | `fixtures/documents/appraisal_informal_sqft.txt` |
| Classified type | `appraisal` |

### 2a. Two guarantees

> The extraction tool producing valid JSON guarantees structural/schema validity, but it does not guarantee that the values are mathematically consistent with one another. In the discrepancy run, the calculated total was `9642.17` while the stated total was `10892.17`, so validation reported `consistent: false` and a delta of `-1250.0`. Valid JSON alone would not catch that arithmetic error; deterministic validation would not by itself catch malformed JSON that cannot be parsed.

### 2b. Refusing to fabricate

> `bonus_monthly: null`  
> `bonus_ytd: null`
>
> The missing bonus fields remain `null` because the source did not provide those values. The schema permits a missing value instead of requiring the extractor to invent one.

### 2c. Normalization

> The source text described the area as “about 2,400 sq ft”, while the extracted value was `gross_living_area_sqft: 2400`. Normalizing during extraction provides a consistent numeric value for downstream validation and processing.

---

## 3. Multi-source synthesis

| Evidence | Value |
|---|---|
| Passing test count | 34 passed |
| Briefing file | `briefing.md` |
| Section the conflict landed in | `Contested` |

### 3a. Annotate, don't arbitrate

> `95.0 percent — supplier_audit (as of 2026-04-10)`  
> `78.0 percent — logistics (as of 2026-04-05)`
>
> Preserving both values, sources, and dates lets the reader see the disagreement and investigate it instead of losing the provenance behind a single reconciled number.

### 3b. Source goes dark

> `### late_shipment_count _[missing source: timeout reading logistics]_`  
> `- missing source: timeout reading logistics`
>
> An unreachable source is explicitly recorded as a timeout, while `production_capacity_utilization` is incomplete because no source reported that metric. The run still finishes because the unavailable source is recorded as incomplete instead of being treated as valid evidence or causing the whole investigation to fail.

### 3c. Dates as a guardrail

> `95.0 percent — supplier_audit (as of 2026-04-10)`  
> `78.0 percent — logistics (as of 2026-04-05)`
>
> The dates show that the two measurements were taken at different times, so the difference cannot automatically be interpreted as a contradiction at the exact same point in time.

---

## 4. Synthesis

### 4a. One principle

> System 2, `discrepancy-run.txt`, most clearly demonstrated “evaluate the output, don't trust the model's word.” The extracted income values were independently checked and the validator found that the calculated monthly total was `9642.17` while the stated total was `10892.17`, producing `consistent: false` and a `-1250.0` discrepancy.

### 4b. Confidence ≠ correctness

> System 2 showed this clearly because extracted values were not accepted simply because they were returned by the extraction process. The deterministic validation compared the individual income components with the stated total and detected that they did not agree. The result was `consistent: false` with a calculated total of `9642.17` versus a stated total of `10892.17`.

### 4c. Apply it

> For a workflow where an LLM extracts structured results from messy documents, I would use deterministic validation with an escalation path. Extracted financial fields could be checked against mathematical relationships and required fields, while inconsistent results could be routed for review. I would instrument extracted values, validation results, discrepancies, retry/escalation decisions, and provenance so that a broken workflow leaves observable evidence instead of silently producing an incorrect result.
